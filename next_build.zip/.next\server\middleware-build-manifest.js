globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/38e9c0d39ba766a7.js",
    "static/chunks/76c064224d953678.js",
    "static/chunks/e6dd030cd2ef21f5.js",
    "static/chunks/f2f58a7e93290fbb.js",
    "static/chunks/turbopack-921182de18f65e48.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];