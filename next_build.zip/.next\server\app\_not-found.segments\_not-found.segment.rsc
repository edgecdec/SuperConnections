1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/450da348558950a5.js","/_next/static/chunks/2f236954d6a65e12.js"],"default"]
3:I[37457,["/_next/static/chunks/450da348558950a5.js","/_next/static/chunks/2f236954d6a65e12.js"],"default"]
0:{"buildId":"Yw3LsFnRyjN1Fm0j6WsAm","rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"loading":null,"isPartial":false}
