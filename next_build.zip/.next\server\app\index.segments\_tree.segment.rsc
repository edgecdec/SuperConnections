:HL["/_next/static/chunks/5e004433c9db2232.css","style"]
0:{"buildId":"Yw3LsFnRyjN1Fm0j6WsAm","tree":{"name":"","paramType":null,"paramKey":"","hasRuntimePrefetch":false,"slots":{"children":{"name":"__PAGE__","paramType":null,"paramKey":"__PAGE__","hasRuntimePrefetch":false,"slots":null,"isRootLayout":false}},"isRootLayout":true},"staleTime":300}
